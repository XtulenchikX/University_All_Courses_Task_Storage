#include <stdio.h>
#include "matrixFunc.h"
#include "matrixMult.h"

double **multiply(double **mass1, int row1, int column1, double **mass2, int row2, int column2)
{
    double **result = NULL;
    if (column1 == row2)
    {
        result = matrix(row1, column2);
        for (int i = 0; i < row1; i++)
        {
            for (int j = 0; j < column2; j++)
            {
                result[i][j] = 0;
                for (int p = 0; p < column1; p++)
                {
                    result[i][j] = result[i][j] + mass1[i][p] * mass2[p][j];
                }
            }
        }
    }
    return result;
}