#include <stdio.h>
#include <stdlib.h>
#include "matrixFunc.h"

double ** matrix(int rows,int columns)
{
    double **mass = (double **) malloc(rows * sizeof(double *));
    for (int i = 0; i < rows; i++)
    {
        mass[i] = (double *) malloc(columns * sizeof(double));
    }
    return(mass);
}

void matrixFr(double **mass, int rows)
{
    for (int i = 0; i < rows; i++)
    {
        free(mass[i]);
    }
    free(mass);
    printf("Success");
}

void matrixDeploy(double **mass, int rows, int columns)
{
    for (int i = 0; i < rows; i++)
    {
        double a;
        for (int j = 0; j < columns; j++)
        {
            printf("\nEnter element mass[%d][%d]=", i+1, j+1);
            scanf("%lf",&a);
            mass[i][j]=a;
        }
    }
}

void matrixApp(double **mass, int rows, int columns)
{
    printf("\n");
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            printf("%.1lf ", mass[i][j]);
        }
        printf("\n");
    }
}