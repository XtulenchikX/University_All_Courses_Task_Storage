#ifndef LABA5_MATRIXFUNC_H
#define LABA5_MATRIXFUNC_H

double ** matrix(int columns,int rows);
void matrixFr(double **mass, int rows);
void matrixDeploy(double **mass, int rows, int columns);
void matrixApp(double **mass, int rows, int columns);

#endif