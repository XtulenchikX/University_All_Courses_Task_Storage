#ifndef LABA5_MATRIXMULT_H
#define LABA5_MATRIXMULT_H

double **multiply(double **mass1, int row1, int column1, double **mass2, int row2, int column2);

#endif