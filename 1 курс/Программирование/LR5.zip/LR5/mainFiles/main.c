#include <stdio.h>
#include "matrixFunc.h"
#include "matrixMult.h"

int main()
{
    int row1, column1, row2, column2;
    printf("Enter number of rows of matrix 1:");
    scanf("%d", &row1);
    printf("\nEnter number of columns of matrix 1:");
    scanf("%d", &column1);

    double **mass1 = matrix(row1, column1);
    matrixDeploy(mass1,row1,column1);

    printf("\n");

    printf("Enter number of rows of matrix 2:");
    scanf("%d", &row2);
    printf("\nEnter number of columns of matrix 2:");
    scanf("%d", &column2);

    double **mass2 = matrix(row2, column2);
    matrixDeploy(mass2,row2,column2);

    printf("\nmatrix 1:\n");
    matrixApp(mass1, row1, column1);
    printf("\nmatrix 2:\n");
    matrixApp(mass2, row2, column2);

    double **result = multiply(mass1, row1, column1, mass2, row2, column2);
    printf("\nThe result of multiplication: \n");
    matrixApp(result, row1, column2);

    printf("\nFreeing up memory for the matrix 1: ");
    matrixFr(mass1, row1);
    printf("\nFreeing up memory for the matrix 2: ");
    matrixFr(mass2, row2);
    printf("\nFreeing up memory for the resulting matrix: ");
    matrixFr(result, row1);

    return 0;
}